import React, { useState } from 'react';
import { Accessibility, Volume2, Mic, Eye, Type, LayoutGrid, Languages, Moon, Loader2, Search } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

const Settings = () => {
  const { settings, updateSetting, loading, t } = useSettings();
  const [langSearch, setLangSearch] = useState('');

  const indianLanguages = [
    { id: 'en', flag: '🇮🇳', name: 'English (India)' },
    { id: 'hi', flag: '🇮🇳', name: 'हिन्दी (Hindi)' },
    { id: 'bn', flag: '🇮🇳', name: 'বাংলা (Bengali)' },
    { id: 'te', flag: '🇮🇳', name: 'తెలుగు (Telugu)' },
    { id: 'mr', flag: '🇮🇳', name: 'मराठी (Marathi)' },
    { id: 'ta', flag: '🇮🇳', name: 'தமிழ் (Tamil)' },
    { id: 'gu', flag: '🇮🇳', name: 'ગુજરાતી (Gujarati)' },
    { id: 'ur', flag: '🇮🇳', name: 'اردو (Urdu)' },
    { id: 'kn', flag: '🇮🇳', name: 'ಕನ್ನಡ (Kannada)' },
    { id: 'ml', flag: '🇮🇳', name: 'മലയാളം (Malayalam)' },
    { id: 'or', flag: '🇮🇳', name: 'ଓଡ଼ିଆ (Odia)' },
    { id: 'pa', flag: '🇮🇳', name: 'ਪੰਜਾਬੀ (Punjabi)' },
    { id: 'as', flag: '🇮🇳', name: 'অসমীয়া (Assamese)' },
    { id: 'ks', flag: '🇮🇳', name: 'कॉशुर (Kashmiri)' },
    { id: 'ne', flag: '🇮🇳', name: 'नेपाली (Nepali)' },
    { id: 'mai', flag: '🇮🇳', name: 'मैथिली (Maithili)' },
    { id: 'sa', flag: '🇮🇳', name: 'संस्कृत (Sanskrit)' },
    { id: 'mr', flag: '🇮🇳', name: 'संथाली (Santali)' },
    { id: 'ko', flag: '🇮🇳', name: 'कोंकणी (Konkani)' },
    { id: 'sd', flag: '🇮🇳', name: 'सिंधी (Sindhi)' },
    { id: 'doi', flag: '🇮🇳', name: 'डोगरी (Dogri)' },
    { id: 'mni', flag: '🇮🇳', name: 'মণিপুরী (Manipuri)' },
    { id: 'brx', flag: '🇮🇳', name: 'बोड़ो (Bodo)' },
  ];

  const filteredLangs = indianLanguages.filter(l => 
    l.name.toLowerCase().includes(langSearch.toLowerCase()) || 
    l.id.toLowerCase().includes(langSearch.toLowerCase())
  );

  if (loading) {
    return (
      <div style={{ display: 'flex', height: '100%', alignItems: 'center', justifyContent: 'center' }}>
        <Loader2 size={48} color="var(--primary-start)" className="animate-spin" />
      </div>
    );
  }

  const ToggleItem = ({ icon: Icon, title, subtitle, checked, onChange }) => (
    <div style={{
      background: 'var(--dynamic-white)',
      padding: '1rem 1.25rem',
      borderRadius: '16px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      boxShadow: 'var(--shadow-sm)',
      marginBottom: '0.75rem',
      border: '1px solid rgba(209,196,233,0.2)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flex: 1 }}>
        <div style={{
          width: 40, height: 40, borderRadius: '12px',
          background: 'var(--surface-alt)', color: 'var(--primary)',
          display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
          <Icon size={18} />
        </div>
        <div>
          <div style={{ fontSize: '0.9375rem', fontWeight: 600, color: 'var(--text-dark)' }}>{title}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{subtitle}</div>
        </div>
      </div>
      <label className="switch">
        <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
        <span className="slider round"></span>
      </label>
    </div>
  );

  const SectionHeader = ({ icon: Icon, title }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', color: 'var(--primary)', marginBottom: '1rem', marginTop: '0.5rem' }}>
      <Icon size={20} />
      <h2 style={{ fontSize: '1.1rem', fontWeight: 800, margin: 0 }}>{title}</h2>
    </div>
  );

  return (
    <div className="settings-page">
      {/* Page Header */}
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--bg-dark)' }}>{t('settings')}</h1>
        <p style={{ color: 'var(--text-muted)', marginTop: '0.25rem' }}>{t('customizeExperience')}</p>
      </div>

      {/* Two-column grid on desktop */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '2rem', alignItems: 'start' }}>

        {/* Left Column */}
        <div>
          {/* Accessibility */}
          <div className="card" style={{ marginBottom: '1.5rem', padding: '1.5rem', background: 'var(--dynamic-white)' }}>
            <SectionHeader icon={Accessibility} title={t('accessibility')} />
            <ToggleItem icon={Volume2} title={t('autoSpeak')} subtitle={t('autoSpeakSub')} checked={settings.auto_speak_ai} onChange={(v) => updateSetting("auto_speak_ai", v)} />
            <ToggleItem icon={Mic} title={t('voiceInput')} subtitle={t('voiceInputSub')} checked={settings.voice_input_enabled} onChange={(v) => updateSetting("voice_input_enabled", v)} />
            <ToggleItem icon={Eye} title={t('highContrast')} subtitle={t('highContrastSub')} checked={settings.high_contrast} onChange={(v) => updateSetting("high_contrast", v)} />
            <ToggleItem icon={Type} title={t('dyslexiaFont')} subtitle={t('dyslexiaFontSub')} checked={settings.dyslexia_friendly_font} onChange={(v) => updateSetting("dyslexia_friendly_font", v)} />
            <ToggleItem icon={LayoutGrid} title={t('iconOnly')} subtitle={t('iconOnlySub')} checked={settings.icon_only_navigation} onChange={(v) => updateSetting("icon_only_navigation", v)} />

            {/* Font Size */}
            <div style={{ background: 'var(--surface-alt)', padding: '1rem', borderRadius: '14px', marginTop: '0.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--primary)', marginBottom: '1rem' }}>
                <Type size={16} />
                <div style={{ fontSize: '0.9rem', fontWeight: 600 }}>{t('fontSize')}</div>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                {['S', 'M', 'L', 'XL'].map((size) => (
                  <button
                    key={size}
                    onClick={() => updateSetting("font_size", size)}
                    style={{
                      flex: 1, height: '44px', borderRadius: '12px',
                      background: settings.font_size === size ? 'var(--gradient)' : 'var(--dynamic-white)',
                      color: settings.font_size === size ? 'white' : 'var(--primary)',
                      border: 'none', fontWeight: 800, fontSize: '0.9rem', cursor: 'pointer',
                      transition: 'all 0.2s',
                      boxShadow: settings.font_size === size ? 'var(--shadow-md)' : 'none'
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div>
          {/* Appearance */}
          <div className="card" style={{ marginBottom: '1.5rem', padding: '1.5rem', background: 'var(--dynamic-white)' }}>
            <SectionHeader icon={Moon} title={t('appearance')} />
            <ToggleItem icon={Moon} title={t('darkMode')} subtitle={t('darkModeSub')} checked={settings.dark_mode} onChange={(v) => updateSetting("dark_mode", v)} />
          </div>

          {/* Language */}
          <div className="card" style={{ marginBottom: '1.5rem', padding: '1.5rem', background: 'var(--dynamic-white)' }}>
            <SectionHeader icon={Languages} title={t('language')} />
            
            {/* Search Box */}
            <div style={{ position: 'relative', marginBottom: '1rem' }}>
              <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--primary)' }} />
              <input 
                type="text" 
                placeholder={t('searchLanguage')} 
                value={langSearch}
                onChange={(e) => setLangSearch(e.target.value)}
                style={{
                  width: '100%', padding: '12px 12px 12px 40px', borderRadius: '12px',
                  background: 'var(--surface-alt)', border: 'none', color: 'var(--text-dark)',
                  fontSize: '0.9rem', fontWeight: 500, outline: 'none'
                }}
              />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', maxHeight: '300px', overflowY: 'auto', paddingRight: '4px' }}>
              {filteredLangs.map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => updateSetting("app_language", lang.id)}
                  style={{
                    width: '100%', padding: '0.875rem 1rem', borderRadius: '14px',
                    background: settings.app_language === lang.id ? 'var(--gradient)' : 'var(--surface-alt)',
                    color: settings.app_language === lang.id ? 'white' : 'var(--primary)',
                    border: 'none', display: 'flex', alignItems: 'center', gap: '0.75rem',
                    fontSize: '0.9375rem', fontWeight: 600, cursor: 'pointer', transition: 'all 0.2s',
                    boxShadow: settings.app_language === lang.id ? 'var(--shadow-md)' : 'none',
                    minHeight: '52px'
                  }}
                >
                  <span style={{ fontSize: '1.25rem' }}>{lang.flag}</span>
                  {lang.name}
                </button>
              ))}
              {filteredLangs.length === 0 && (
                <div style={{ textAlign: 'center', padding: '1rem', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                  {t('noLanguageFound')} "{langSearch}"
                </div>
              )}
            </div>
          </div>

          {/* Notice */}
          <div style={{
            background: 'var(--surface-alt)',
            padding: '1.25rem',
            borderRadius: '16px',
            fontSize: '0.8rem',
            color: 'var(--primary)',
            lineHeight: 1.6,
            fontWeight: 500,
            border: '1px solid rgba(103,58,183,0.1)'
          }}>
            <strong>Accessibility First:</strong> {t('accessibilityNotice')}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;


