import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Loader2 } from 'lucide-react';
import api from '../api';

const CheckIn = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const mood = location.state?.mood || 'Okay';

  const [answers, setAnswers] = useState(['', '', '']);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const questionSets = {
    "Great": [
      { text: "What contributed to your positive energy today?", opts: ["Achievement", "Socializing", "Self-care", "Nature", "Other"] },
      { text: "How likely are you to share this joy with others?", opts: ["Not at all", "Maybe", "Likely", "Very Likely", "Full of joy"] },
      { text: "What is one thing you're grateful for right now?", opts: ["Health", "Relationships", "Career", "My Progress", "Small Wins"] }
    ],
    "Angry": [
      { text: "Is there a specific trigger for this anger?", opts: ["Work/Study", "A Person", "Injustice", "Daily Hassles", "Unknown"] },
      { text: "How is your body feeling right now?", opts: ["Tense muscles", "Rapid heart", "Clenched jaw", "Hot/Sweaty", "Restless"] },
      { text: "What would help you cool down first?", opts: ["Deep breaths", "Physical activity", "Alone time", "Writing it out", "Distraction"] }
    ],
    "Sad": [
      { text: "What is weighing on your heart today?", opts: ["Loss/Grief", "Loneliness", "Disappointment", "Old Memories", "Unknown"] },
      { text: "Do you feel like you need connection or quiet?", opts: ["Need a friend", "Need quiet", "Need a cry", "Just a hug", "Don't know"] },
      { text: "How can you be kind to yourself today?", opts: ["Rest", "Good food", "Treat myself", "Patience", "Nature walk"] }
    ],
    "Stressed": [
      { text: "Where are you feeling this stress in your body?", opts: ["Chest/Heart", "Stomach", "Head/Mind", "Shoulders", "Everywhere"] },
      { text: "Is there a specific trigger you can identify?", opts: ["Work/Study", "Health", "Social", "Unknown", "Personal"] },
      { text: "Would you like to try a grounding exercise now?", opts: ["Yes, guide me", "Maybe later", "I'm okay", "Not right now", "Need a distraction"] }
    ],
    "Tired": [
      { text: "How drained do you feel emotionally?", opts: ["Slightly", "Moderate", "Heavy", "Empty", "Completely Overwhelmed"] },
      { text: "What feels like the heaviest burden right now?", opts: ["Workload", "Expectations", "Lack of Sleep", "No Support", "Everything"] },
      { text: "What is one small step towards rest you can take?", opts: ["5 min nap", "Close laptop", "Deep Breaths", "Drink water", "Call a friend"] }
    ],
    "Okay": [
      { text: "How would you rate your energy level today?", opts: ["Very Low", "Low", "Moderate", "High", "Very High"] },
      { text: "How well did you sleep last night?", opts: ["Very Poorly", "Poorly", "Okay", "Well", "Very Well"] },
      { text: "Are you experiencing any physical tension?", opts: ["A Lot", "Some", "A Little", "Not Much", "None"] }
    ]
  };

  const currentQuestions = questionSets[mood] || questionSets["Okay"];

  const handleOptionSelect = (qIdx, opt) => {
    const newAnswers = [...answers];
    newAnswers[qIdx] = opt;
    setAnswers(newAnswers);
  };

  const handleComplete = async () => {
    if (!isComplete) return;
    setIsSubmitting(true);
    try {
      const payload = {
        mood: mood,
        answers: { q1: answers[0], q2: answers[1], q3: answers[2] }
      };
      await api.post('/api/mood/checkin/', payload);
      navigate('/checkin-complete', { state: { mood } });
    } catch (error) {
      console.error('Error submitting check-in:', error);
      navigate('/checkin-complete', { state: { mood } });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isComplete = answers.every(ans => ans !== '');

  return (
    <div style={{ minHeight: '100vh', background: '#FBFAFF', display: 'flex', flexDirection: 'column', padding: '24px' }}>
      <button 
        onClick={() => navigate(-1)}
        style={{ width: 44, height: 44, borderRadius: '50%', background: 'transparent', border: 'none', color: '#7B1FA2', display: 'flex', alignItems: 'center', justifyContent: 'center', marginLeft: '-12px', marginBottom: '8px' }}
      >
        <ArrowLeft size={28} />
      </button>

      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#4A148C', lineHeight: 1.2, margin: 0 }}>
          A few quick questions
        </h1>
        <p style={{ fontSize: '1rem', color: '#AB47BC', marginTop: '8px', lineHeight: 1.4, fontWeight: 500 }}>
          Tailored for your {mood} mood
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', marginBottom: '48px' }}>
        {currentQuestions.map((q, qIdx) => (
          <div key={qIdx} style={{ background: 'white', padding: '24px', borderRadius: '32px', boxShadow: '0 8px 16px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', gap: '4px', marginBottom: '20px' }}>
              <span style={{ fontSize: '1.125rem', fontWeight: 800, color: '#AB47BC' }}>Q{qIdx + 1}</span>
              <h3 style={{ fontSize: '1.0625rem', fontWeight: 700, color: '#7B1FA2', margin: 0 }}>{q.text}</h3>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {q.opts.map((opt) => (
                <button
                  key={opt}
                  onClick={() => handleOptionSelect(qIdx, opt)}
                  style={{ 
                    width: '100%', 
                    height: '56px', 
                    borderRadius: '16px', 
                    background: answers[qIdx] === opt ? '#F3E5F5' : '#FBFAFF', 
                    border: answers[qIdx] === opt ? 'none' : '1px solid #F3E5F5',
                    color: answers[qIdx] === opt ? '#7B1FA2' : '#AB47BC',
                    fontSize: '1rem',
                    fontWeight: answers[qIdx] === opt ? 700 : 500,
                    cursor: 'pointer'
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={handleComplete}
        disabled={!isComplete || isSubmitting}
        style={{
          width: '100%',
          height: '64px',
          borderRadius: '32px',
          background: isComplete ? 'linear-gradient(90deg, #90CAF9 0%, #E1BEE7 100%)' : 'rgba(0,0,0,0.05)',
          color: isComplete ? 'white' : '#BDBDBD',
          fontSize: '1.125rem',
          fontWeight: 700,
          border: 'none',
          boxShadow: isComplete ? '0 8px 16px rgba(0,0,0,0.1)' : 'none',
          cursor: isComplete && !isSubmitting ? 'pointer' : 'default',
          marginBottom: '32px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '12px'
        }}
      >
        {isSubmitting ? <Loader2 className="animate-spin" /> : 'Complete Check-In'}
      </motion.button>
    </div>
  );
};

export default CheckIn;
