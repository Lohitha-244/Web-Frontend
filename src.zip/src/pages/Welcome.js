import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Sparkles, Shield } from 'lucide-react';
import { motion } from 'framer-motion';

const Welcome = () => {
  const navigate = useNavigate();

  return (
    <div className="auth-layout">
      {/* Desktop Banner */}
      <div className="auth-banner">
        <div style={{ zIndex: 1, maxWidth: '400px' }}>
          <h1 style={{ fontSize: '3.5rem', fontWeight: 800, marginBottom: '1.5rem', lineHeight: 1.1 }}>Solace</h1>
          <p style={{ fontSize: '1.25rem', fontWeight: 500, opacity: 0.9, lineHeight: 1.6 }}>
            "Healing is not linear. Take your time, trust the process."
          </p>
        </div>
      </div>

      <div className="auth-content" style={{ display: 'flex', alignItems: 'center' }}>
        <div style={{ 
          display: 'flex', 
          flexDirection: 'column', 
          maxWidth: '440px', 
          width: '100%', 
          margin: '0 auto',
          padding: '1.5rem 1rem 2rem 1rem'
        }}>
          
          <div style={{ textAlign: 'center', marginBottom: '32px' }}>
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              style={{
                width: '100px',
                height: '100px',
                borderRadius: '50%',
                background: 'var(--gradient)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 12px 32px rgba(103, 58, 183, 0.2)',
                margin: '0 auto 24px auto'
              }}
            >
              <Heart size={50} color="white" fill="white" />
            </motion.div>

            <h1 style={{ 
              fontSize: '2.5rem', 
              fontWeight: 800, 
              color: 'var(--primary-start)', 
              lineHeight: 1.2,
              marginBottom: '16px'
            }}>
              Welcome to Solace
            </h1>

            <p style={{ 
              fontSize: '1.125rem', 
              color: 'var(--text-muted)', 
              fontWeight: 500,
            }}>
              Your Safe Space to Talk
            </p>
          </div>

          {/* Info Cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '100%', marginBottom: '32px' }}>
            <div className="card" style={{ 
              background: 'white', 
              padding: '20px', 
              display: 'flex', 
              alignItems: 'center',
              border: '1px solid rgba(209, 196, 233, 0.4)'
            }}>
              <div style={{
                width: '56px',
                height: '56px',
                borderRadius: '50%',
                background: '#EBE3FF',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <Sparkles size={28} color="var(--primary-start)" />
              </div>
              <div style={{ marginLeft: '20px' }}>
                <div style={{ fontSize: '1.125rem', fontWeight: 800, color: 'var(--primary-start)' }}>
                  AI-Powered Support
                </div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
                  24/7 compassionate conversations when you need them
                </div>
              </div>
            </div>

            <div className="card" style={{ 
              background: 'white', 
              padding: '20px', 
              display: 'flex', 
              alignItems: 'center',
              border: '1px solid rgba(209, 196, 233, 0.4)'
            }}>
              <div style={{
                width: '56px',
                height: '56px',
                borderRadius: '50%',
                background: '#F3EFFF',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <Shield size={28} color="var(--primary-start)" />
              </div>
              <div style={{ marginLeft: '20px' }}>
                <div style={{ fontSize: '1.125rem', fontWeight: 800, color: 'var(--primary-start)' }}>
                  Private & Secure
                </div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
                  Your data stays confidential and protected
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate('/login')}
            style={{
              width: '100%',
              height: '64px',
              borderRadius: '32px',
              background: 'var(--gradient)',
              color: 'white',
              fontSize: '1.125rem',
              fontWeight: 800,
              border: 'none',
              boxShadow: '0 8px 24px rgba(103, 58, 183, 0.25)',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(103, 58, 183, 0.35)'; }}
            onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(103, 58, 183, 0.25)'; }}
          >
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
